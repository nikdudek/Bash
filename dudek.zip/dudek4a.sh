#!/usr/bin/bash

echo $$ >> endlessScript.pid

while :
do
  echo "Pętla"
  sleep 1
done
