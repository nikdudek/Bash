#!/usr/bin/bash

exec 1> "wyjscie.txt"
uname -p
uname -s -v -r
whoami
echo $HOME
