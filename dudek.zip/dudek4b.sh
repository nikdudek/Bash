#!/usr/bin/bash

kill `cat endlessScript.pid`
echo "Zabito"
