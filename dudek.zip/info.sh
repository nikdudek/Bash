#!/usr/bin/bash

  case $1 in
    "-hd")
      echo "HDD"
      df -h ;;
    "-ram")
      free -m ;;
    "-cpu")
      cat /proc/cpuinfo ;;
    "-all")
      df -h
      free -m
      cat /proc/cpuinfo ;;
  esac

