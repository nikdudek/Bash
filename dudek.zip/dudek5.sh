#!/usr/bin/bash

p1=$1
p2=$2

read > tekst.txt

function zamien() {
  sed -i "s/$1/$2/" tekst.txt
}

zamien $p1 $p2
cat tekst.txt
rm tekst.txt
