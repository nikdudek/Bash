#!/usr/bin/bash

echo "Jako pierwszy parametr podaj komendę:"
echo "utworz nazwa_pliku - zostanie utworzony plik o danej nazwie"
echo "katalog nazwa_katalogu - zostanie utworzony katalog o danej nazwie"
echo "usun nazwa_pliku - zostanie usunięty plik o danej nazwie"
echo "skopiuj sciezka_pliku katalog_docelowy - zostanie skopiowany plik o danej nazwie do podanego katalogu"
echo "przenies sciezka_pliku katalog_docelowy - zostanie przeniesiony plik o danej nazwie do podanego katalogu"
echo ""

case $1 in

"utworz")
 touch "$2" ;;
 
"katalog")
 mkdir -p "$2" ;;

"usun")
 rm "$2" ;;

"skopiuj")
 cp "$2" "$3" ;;

"przenies")
 mv "$2" "$3" ;;

*)
 echo "Zly wybór. Zamykam skrypt.."
esac

echo ""
